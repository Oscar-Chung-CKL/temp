COMP2396B Object-oriented programming and Java

Assignment 4: A two-player Tic-Tac-Toe Game

Author: Chung Ka Lok , 3035781249

How to start the game:
1. Start the Server.java
2. Start the Client.java once, then enter the name and submit.
3. Start the Client.java for the second time, enter the name and submit
4. Now the game would start, and the first client connected to the server
	will be the one who make the move first, and the sign will be "X"